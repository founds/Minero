Minero
-----------

**Raptor** for extracting and displaying information from a set of files of the same type; and creating a single CSV file with all the selected information.

The information in the files may be in multiple rows::

    PC01.txt:
    User=ms123
    Name=Mayra Sanz
    OS=GNU/Linux
    IP=10.226.140.1

But, also, the information may be in several columns. It is possible to read data from multiple fields in a single line::
...
...
...